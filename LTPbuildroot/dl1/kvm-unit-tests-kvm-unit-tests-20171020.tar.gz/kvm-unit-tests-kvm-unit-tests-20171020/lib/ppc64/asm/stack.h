#ifndef _ASMPPC64_STACK_H_
#define _ASMPPC64_STACK_H_

#ifndef _STACK_H_
#error Do not directly include <asm/stack.h>. Just use <stack.h>.
#endif

#endif
