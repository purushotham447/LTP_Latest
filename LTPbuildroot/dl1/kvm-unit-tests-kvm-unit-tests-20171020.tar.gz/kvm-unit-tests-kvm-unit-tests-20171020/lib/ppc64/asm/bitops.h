#ifndef _ASMPPC64_BITOPS_H_
#define _ASMPPC64_BITOPS_H_

#ifndef _BITOPS_H_
#error only <bitops.h> can be included directly
#endif

#define BITS_PER_LONG	64

#endif
