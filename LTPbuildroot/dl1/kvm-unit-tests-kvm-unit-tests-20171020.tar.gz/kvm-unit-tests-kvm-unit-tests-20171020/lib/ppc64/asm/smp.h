#include "../../powerpc/asm/smp.h"
