#ifndef _ASMPPC64_SPINLOCK_H_
#define _ASMPPC64_SPINLOCK_H_

#include <asm-generic/spinlock.h>

#endif /* _ASMPPC64_SPINLOCK_H_ */
